import javax.swing.*;
import java.awt.*;

public class DbConnection {
    public static void main(String[] args) throws ClassNotFoundException {
        Class.forName("");
    }
}
