import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class FindPath extends JFrame {
    private static final long serialVersionUID = 1L;
    public static Point[] points;
    public static ArrayList<String> list,list_1;
    public static ArrayList<String> buslist;

    public static final int W_FRAME = 540;
    public static final int H_FRAME = 360;
    private JPanel contentPane;
    private JButton button_login;
    private JLabel label_username, label_password;
    public static JTextField textField_username;
    public static JTextField destText;
    private Insets insets;

    private JLabel distance;

    public static JTextField textDist;
    public JLabel busName,vara,time;
    public JLabel destName;
    public JLabel currentTime;
    public JLabel price;

    public FindPath() throws HeadlessException {
        setTitle("Find Path");
        setSize(700,700);
        setIconImage(new ImageIcon("C:\\Users\\MORSALIN RAVI\\Desktop\\busspass\\BusPass\\BusPass\\src\\icon.png").getImage());

        insets = this.getInsets();

        GUI();


        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    private void GUI() {

        contentPane = new JPanel();
        contentPane.setLayout(null);
        contentPane.setBounds(insets.left, insets.top, W_FRAME - insets.left - insets.right,
                H_FRAME - insets.bottom - insets.top);

        label_username = new JLabel("Starting Point: ");
        label_username.setFont(new Font(Font.MONOSPACED, Font.BOLD, 15));
        label_username.setBounds(100, 100, 180, 20);
        contentPane.add(label_username);

        label_password = new JLabel("Destination Point: ");
        label_password.setFont(label_username.getFont());
        label_password.setBounds(label_username.getX(), label_username.getY() + 40,
                label_username.getWidth(), label_username.getHeight());
        contentPane.add(label_password);


        textField_username = new JTextField();
        textField_username.setBounds(label_username.getX() + label_username.getWidth() + 30,
                label_username.getY(), 250, label_username.getHeight());
        textField_username.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //passwordField_password.requestFocus();
            }
        });
        contentPane.add(textField_username);

        destText = new JTextField();
        destText.setBounds(textField_username.getX(), label_password.getY(),
                250, label_password.getHeight());
        destText.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                button_login.doClick();
            }
        });
        contentPane.add(destText);


        distance = new JLabel("Total Distance: ");
        distance.setFont(label_username.getFont());
        distance.setBounds(label_username.getX(), label_username.getY() + 80,
                label_username.getWidth(), label_username.getHeight());
        contentPane.add(distance);

        textDist=new JTextField();
        textDist.setFont(distance.getFont());
        textDist.setBounds(destText.getX(),distance.getY(),destText.getWidth(),destText.getHeight());
        contentPane.add(textDist);
        textDist.addActionListener((e)->{
            System.out.println();
        });



        button_login = new JButton("Find Path");
        button_login.setBounds(textField_username.getX(), label_username.getY() + 120, 120, 30);
        button_login.setFocusPainted(false);
        button_login.setBackground(Color.GREEN);
        button_login.setFont(new Font(Font.MONOSPACED,Font.BOLD,16));
        button_login.setUI(new StyledButtonUI());
        button_login.addActionListener(e->{
            //new Result();

            String start="";
            String dest="";
            start=textField_username.getText();
            dest=destText.getText();
            System.out.println(start);
            System.out.println(dest);
            try {
                fetchDataFromCustomJson(start,dest);

            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }

        });
        contentPane.add(button_login);

        contentPane.setBackground(Color.pink);

                busName=new JLabel("");
        busName.setSize(300,30);
        busName.setLocation(label_username.getX(),250);
        busName.setFont(new Font(Font.MONOSPACED,Font.BOLD,18));
        busName.setForeground(Color.BLUE);
        contentPane.add(busName);

        destName=new JLabel("");//waiting for implements
        destName.setSize(300,30);
        destName.setLocation(label_username.getX(),290);
        destName.setFont(new Font(Font.MONOSPACED,Font.BOLD,18));
        destName.setForeground(Color.BLUE);
        contentPane.add(destName);

        vara=new JLabel("");//waiting for implements
        vara.setSize(300,30);
        vara.setLocation(label_username.getX(),330);
        vara.setFont(new Font(Font.MONOSPACED,Font.BOLD,18));
        vara.setForeground(Color.BLUE);
        contentPane.add(vara);


        time=new JLabel("");//waiting for implement
        time.setSize(300,30);
        time.setLocation(label_username.getX(),370);
        time.setFont(new Font(Font.MONOSPACED,Font.BOLD,18));
        time.setForeground(Color.BLUE);
        contentPane.add(time);

        price=new JLabel("");//waiting for implement
        price.setSize(300,30);
        price.setLocation(label_username.getX(),375);
        price.setFont(new Font(Font.MONOSPACED,Font.BOLD,18));
        price.setForeground(Color.BLUE);
        contentPane.add(price);


        currentTime=new JLabel(new Date().toString());//waiting for implement
        currentTime.setSize(350,30);
        currentTime.setLocation(label_username.getX()-10,405);
        currentTime.setFont(new Font(Font.MONOSPACED,Font.BOLD,18));
        currentTime.setForeground(Color.BLUE);
        contentPane.add(currentTime);


        setResizable(false);
        setContentPane(contentPane);
    }
    private static void fetchDataFromStart() throws IOException {
        Path path;
        list=new ArrayList<>();
        path= Path.of("C:\\Users\\MORSALIN RAVI\\Desktop\\busspass\\BusPass\\BusPass\\src\\main\\resources\\StartPoint.txt");
        var s=  Files.readAllLines(path);
        list= (ArrayList<String>) s;
    }
    private static void fetchDataFromDestination() throws IOException {
        Path path;
        list_1=new ArrayList<>();
        path= Path.of("C:\\Users\\MORSALIN RAVI\\Desktop\\busspass\\BusPass\\BusPass\\src\\main\\resources\\DestPoint.txt");
        var s=  Files.readAllLines(path);
        list_1= (ArrayList<String>) s;
    }
    private static void fetchDataFromBusList() throws IOException {
        Path path;
        buslist=new ArrayList<>();
        path= Path.of("C:\\Users\\MORSALIN RAVI\\Desktop\\busspass\\BusPass\\BusPass\\src\\main\\resources\\BusName.txt");
        var s=  Files.readAllLines(path);
        buslist= (ArrayList<String>) s;
    }
    //make custom funny JSON
    public  void fetchDataFromCustomJson(String start,String dest) throws IOException {
        fetchDataFromStart();
        fetchDataFromDestination();
        fetchDataFromBusList();
        points= new Point[list.size()];

//      System.out.println(Arrays.toString(Arrays.stream(points).toArray()));

        for (int i = 0; i < list.size(); i++) {
            points[i]=new Point();
            points[i].setStart(list.get(i));
            points[i].setDest(list_1.get(i));
            points[i].setBus(buslist.get(i));

        }
        var s=new Point();
        s.setStart(start);
        s.setDest(dest);
        int value=Integer.parseInt(String.valueOf(textDist.getText()));
        value*=5;
        for (int i = 0; i < points.length; i++)
            if ((points[i].getStart().equals(s.getStart()))&&(points[i].getDest().equals(s.getDest())))
                //System.out.println(points[i].getBus());
            {
                busName.setText("Bus Name: "+points[i].getBus());
                destName.setText("From: "+start+" To: "+dest);
                vara.setText("Service Time: 6AM-11PM");
                price.setText("Ticket Price: "+value+"TK");
            }
    }
    public static void main(String[] args) throws IOException {
    new FindPath();

    }

}
class Point{
    public String start;
    public String dest;
    public String bus;

    public Point() {
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getDest() {
        return dest;
    }

    public void setDest(String dest) {
        this.dest = dest;
    }

    public String getBus() {
        return bus;
    }

    public void setBus(String bus) {
        this.bus = bus;
    }

    @Override
    public String toString() {
        return "Point{" +
                "Start='" + start + '\'' +
                ", Dest='" + dest + '\'' +
                ", Bus='" + bus + '\'' +
                '}';
    }
}

